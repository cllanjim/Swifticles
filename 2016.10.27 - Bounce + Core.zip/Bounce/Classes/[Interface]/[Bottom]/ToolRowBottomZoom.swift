//
//  ToolRowBottomZoom.swift
//  Bounce
//
//  Created by Raptis, Nicholas on 9/15/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import Foundation

class ToolRowBottomZoom: ToolRow
{
    
    //@IBOutlet weak internal var toolRowEdit: ToolRowBottomEdit! {
    //    didSet { toolRows.append(toolRowEdit) }
    //}
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setUp() {
        super.setUp()
    }
    
    override func refreshUI() {
        super.refreshUI()
        
    }
    
    override func segmentSelected(segment:TBSegment, index: Int) {
        
    }
    
    override func checkBoxToggled(checkBox:TBCheckBox, checked: Bool) {
        
    }
    
}

