//
//  HMButton.swift
//  Bounce
//
//  Created by Nicholas Raptis on 9/14/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import Foundation

import UIKit

class HMButton: RRButton {
    override func setUp() {
        super.setUp()
        styleSetHomeMenuButton()
    }
    
}


