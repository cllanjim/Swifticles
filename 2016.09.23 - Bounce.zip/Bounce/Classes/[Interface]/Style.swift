//
//  Style.swift
//  Bounce
//
//  Created by Raptis, Nicholas on 8/24/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import UIKit

let styleColorToolbarButtonFillPressed = UIColor(red: 55.0 / 255.0, green: 98.0 / 255.0, blue: 195.0 / 255.0, alpha: 1.0)

let styleColorSegmentFill = UIColor(red: 0.16, green: 0.16, blue: 0.16, alpha: 1.0)
//let styleColorSegmentFillDown //= //UIColor(red: 0.16, green: 0.16, blue: 0.16, alpha: 1.0)

let styleColorSegmentFillSelected = styleColorToolbarButtonFillPressed

let styleColorSegmentStroke = styleColorToolbarButtonFillPressed
let styleColorSegmentStrokeSelected = styleColorToolbarButtonFillPressed

let styleColorHomeMenuButtonBack = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
let styleColorHomeMenuButtonBackDown = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)

let styleColorToolbarMain = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.92)
let styleColorToolbarRow = UIColor(red: 0.04, green: 0.04, blue: 0.04, alpha: 0.86)


//let styleColorSegmentStrokeSelected = styleColorToolbarButtonFillPressed

//RGB(55,98,195)
//let

//blue
//

//class Style {
//}
