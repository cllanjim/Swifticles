//
//  ToolRowZoomAccessory.swift
//  Bounce
//
//  Created by Nicholas Raptis on 9/24/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import Foundation

class ToolRowZoomAccessory : ToolRow
{
    override func setUp() {
        super.setUp()
        
    }
}
