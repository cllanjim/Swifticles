//
//  CGRect+Extras.swift
//  Bounce
//
//  Created by Raptis, Nicholas on 10/17/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import UIKit

extension CGRect {
    
    
    //open class func getAspectFit()
    
    /*
     - (FrameInfo *)frameInfoAspectFit:(CGSize)videoSize forFrame:(CGRect)screenRect{
     FrameInfo *info = [[FrameInfo alloc] init];
     
     info.scale = 1.0f;
     info.size = CGSizeMake(screenRect.size.width, screenRect.size.height);
     if(videoSize.width > 0 && videoSize.height > 0 && screenRect.size.width > 0 && screenRect.size.height > 0)
     {
     if((videoSize.width / videoSize.height) > (screenRect.size.width / screenRect.size.height))info.scale = screenRect.size.width / videoSize.width;
     else info.scale = screenRect.size.height / videoSize.height;
     info.size = CGSizeMake(videoSize.width * info.scale, videoSize.height * info.scale);
     }
     
     return info;
     }
     
     - (FrameInfo *)frameInfoAspectFill:(CGSize)videoSize forFrame:(CGRect)screenRect{
     FrameInfo *info = [[FrameInfo alloc] init];
     
     info.scale = 1.0f;
     info.size = CGSizeMake(screenRect.size.width, screenRect.size.height);
     if(videoSize.width > 0 && videoSize.height > 0 && screenRect.size.width > 0 && screenRect.size.height > 0)
     {
     if((videoSize.width / videoSize.height) < (screenRect.size.width / screenRect.size.height))info.scale = screenRect.size.width / videoSize.width;
     else info.scale = screenRect.size.height / videoSize.height;
     info.size = CGSizeMake(videoSize.width * info.scale, videoSize.height * info.scale);
     }
     
     return info;
     }
     */
    
    
}


