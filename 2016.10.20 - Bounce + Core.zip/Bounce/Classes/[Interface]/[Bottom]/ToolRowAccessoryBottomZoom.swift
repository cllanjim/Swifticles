//
//  ToolRowAccessoryBottomZoom.swift
//  Bounce
//
//  Created by Raptis, Nicholas on 10/18/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import UIKit

class ToolRowAccessoryBottomZoom: ToolRow
{
    override func setUp() {
        super.setUp()
        
    }
}


