//
//  ToolRowBottomEdit.swift
//  Bounce
//
//  Created by Raptis, Nicholas on 9/14/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import UIKit

class ToolRowBottomEdit: ToolView
{
    override func setUp() {
        super.setUp()
        
    }
}
