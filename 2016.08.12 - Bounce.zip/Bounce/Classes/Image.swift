//
//  Image.swift
//  CombinedGL
//
//  Created by Nicholas Raptis on 8/1/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

import Foundation


//private class func Load(filename: String, inout width: GLsizei, inout height: GLsizei) -> UnsafeMutablePointer<()> {