//
//  WorldViewController.swift
//  SwiftFunhouse
//
//  Created by Raptis, Nicholas on 7/18/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//

import UIKit

class WorldViewController: UIViewController {
    
    
    deinit {
        print("Deinit \(self)")
    }
    
}
